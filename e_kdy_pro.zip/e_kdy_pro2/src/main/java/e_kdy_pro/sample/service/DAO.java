package e_kdy_pro.sample.service;

import java.sql.SQLException;
import java.util.List;



import e_kdy_pro.sample.serviceImpl.BoardVO;

import e_kdy_pro.sample.serviceImpl.MemberVO;

public interface DAO {
	
	List<BoardVO> selectListBoard(int startNum, int lastNum) throws SQLException;
	int selectBoardCount() throws SQLException;
	BoardVO selectBoard(int num) throws SQLException;
	void changeHits(int num) throws SQLException;
	void insertBoard(BoardVO insertWrite) throws SQLException;
	int insertMember(MemberVO member);
	String selectIDandPass(String id, String SHApassword);
	
}
