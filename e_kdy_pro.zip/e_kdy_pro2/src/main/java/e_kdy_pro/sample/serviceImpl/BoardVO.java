package e_kdy_pro.sample.serviceImpl;

import java.sql.Date;

public class BoardVO {
	
	private int num;
	private String id;
	private String title;
	private String content;
	private Date uploadeddate;
	private int hits;
	private String theme;
	
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getUploadeddate() {
		return uploadeddate;
	}
	public void setUploadeddate(Date uploadeddate) {
		this.uploadeddate = uploadeddate;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	
}
