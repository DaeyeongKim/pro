package e_kdy_pro.sample.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import e_kdy_pro.sample.common.JDBCUtil;
import e_kdy_pro.sample.service.DAO;
import e_kdy_pro.sample.vo.BkieReservePlace;



@Repository("daoJDBC")
public class DAOJDBC implements DAO{
	
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	private final String SELECT_BOARD = "select * from kdy_board where num = ?";
	private final String SELECT_QR = "select * from (select * from kdy_board order by uploadeddate desc) where rownum BETWEEN ? AND ?";
	private final String SELECT_COUNT = "select count(*) as total_count from kdy_board";
	private final String CHANGE_HITS = "update kdy_board set hits = hits + 1 where num = ?";
	private final String INSERT_BOARD = "insert into kdy_board(num, id, title, content, uploadeddate, hits, theme) values(kdy_seq.nextval,?,?,?,sysdate,?,?)";
	private final String DELETE_BOARD = "delete kdy_board where num = ? and id = ?"; 
	private final String INSERT_MEMBER = "insert into kdy_member(id, password, name, email, tel, address) values(?,?,?,?,?,?)";
	private final String SELECT_MEMBER = "select id from kdy_member where id = ? and password = ?";
	
	
	
	//게시물 리스트 가져오는 메소드
	public List<BoardVO> selectListBoard(int startNum, int lastNum) throws SQLException { 
		
		System.out.println("selectList처리");
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement(SELECT_QR);
		stmt.setInt(1, startNum);
		stmt.setInt(2, lastNum);
		
		rs = stmt.executeQuery();
		
		List<BoardVO> list = new ArrayList<BoardVO>();
		
		while(rs.next()) {
			
			BoardVO board = new BoardVO();
			board.setNum(rs.getInt("num"));
			board.setId(rs.getString("id"));
			board.setTitle(rs.getString("title"));
			board.setUploadeddate(rs.getDate("uploadeddate"));
			board.setHits(rs.getInt("hits"));
			list.add(board);
			
		}
		
		JDBCUtil.close(rs, stmt, conn);
		
		return list;
	}
	
	//등록된 게시물 수 가져오는 메소드
	public int selectBoardCount() throws SQLException {
		
		int count = 0;
		
		System.out.println("boardcount처리");
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement(SELECT_COUNT);
		
		rs = stmt.executeQuery();
		
		if(rs.next()) {
		count = rs.getInt(1);
		}
		JDBCUtil.close(rs, stmt, conn);
		
		return count;
		
	}
	
	//게시물 읽기 메소드
	public BoardVO selectBoard(int num) throws SQLException {
		
		System.out.println("selectboard");
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement(SELECT_BOARD);
		stmt.setInt(1, num);
		rs = stmt.executeQuery();
		
		BoardVO board = null;
		
		if(rs.next()) {
			
			board = new BoardVO(); 
			board.setNum(rs.getInt("num"));
			board.setId(rs.getString("id"));
			board.setTitle(rs.getNString("title"));
			board.setContent(rs.getNString("content"));
			board.setUploadeddate(rs.getDate("uploadeddate"));
			board.setHits(rs.getInt("hits"));
		
		}
		
		JDBCUtil.close(rs, stmt, conn);
		
		return board;
		
	}
	
	//조회수 증가 메소드
	public void changeHits(int num) throws SQLException {
		
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement(CHANGE_HITS);
		stmt.setInt(1, num);
		stmt.executeUpdate();
		
		JDBCUtil.close(stmt, conn);
		
	}
	
	//게시물 등록 메소드
	public void insertBoard(BoardVO insertWrite) throws SQLException {
		//num, id, title, content, uploadeddate, theme
		
		int hits = 0;
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement(INSERT_BOARD);
		
		stmt.setString(1, insertWrite.getId());
		stmt.setString(2, insertWrite.getTitle());
		stmt.setString(3, insertWrite.getContent());
		stmt.setInt(4, hits);
		stmt.setString(5, insertWrite.getTheme());
		stmt.executeUpdate();
		JDBCUtil.close(stmt, conn);
		
	}
	
	//게시물 삭제 메소드
	public void deleteBoard(int num) {
		
		
		
		
		
	}
	
	//회원가입 정보 입력 메소드
	public int insertMember(MemberVO member) {
		int result= 0;
		conn = JDBCUtil.getConnection();
		try {
			stmt = conn.prepareStatement(INSERT_MEMBER);
		
			stmt.setString(1, member.getId());
			stmt.setString(2, member.getPassword());
			stmt.setString(3, member.getName());
			stmt.setString(4, member.getEmail());
			stmt.setInt(5, member.getTel());
			stmt.setString(6, member.getAddress());
			result = stmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			
			System.out.println("아이디 중복");
			
			e.printStackTrace();
		}
		
		
		JDBCUtil.close(stmt, conn);
		
		return result;
		
	}

	//중복체크 후 로그인 메소드
	public String selectIDandPass(String id, String SHApassword) {
		
		conn = JDBCUtil.getConnection();
		String login = null;
		try {
			
			stmt = conn.prepareStatement(SELECT_MEMBER);
			stmt.setString(1, id);
			stmt.setString(2, SHApassword);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				
				login = rs.getString("id");
				
			}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return login;
		
	}
	
	public List<BkieReservePlace> selectRent() throws SQLException {
		
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement("SELECT * FROM bike_reserve_place");
		rs = stmt.executeQuery();
		
		BkieReservePlace tr = null;
		List<BkieReservePlace> list = new ArrayList<BkieReservePlace>();
		
		while(rs.next()) {
			
			tr = new BkieReservePlace(); 
			tr.setReservePlaceAddr(rs.getString("bike_reserve_place_addr"));
			tr.setReservePlaceName(rs.getString("bike_reserve_place_name"));
			tr.setReservePlaceId(rs.getInt("bike_reserve_place_id"));
			list.add(tr);
		}
		
		JDBCUtil.close(rs, stmt, conn);
		return list;
	}
	
	public List<BkieReservePlace> selectSearchRent(String search) throws SQLException {
		
		conn = JDBCUtil.getConnection();
		stmt = conn.prepareStatement("SELECT * FROM bicycle_rent WHERE address LIKE ? OR place_name LIKE ?");
		stmt.setString(1,"%"+search+"%");
		stmt.setString(2,"%"+search+"%");
		rs = stmt.executeQuery();
		
		BkieReservePlace tr = null;
		List<BkieReservePlace> list = new ArrayList<BkieReservePlace>();
		
		while(rs.next()) {
			
			tr = new BkieReservePlace(); 
			tr.setReservePlaceAddr(rs.getString("address"));
			tr.setReservePlaceName(rs.getString("place_name"));
			
			list.add(tr);
		
		}
		
		JDBCUtil.close(rs, stmt, conn);
		return list;
	}
	
}


