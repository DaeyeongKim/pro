package e_kdy_pro.sample.web;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import e_kdy_pro.sample.security.SHA256;
import e_kdy_pro.sample.serviceImpl.DAOJDBC;
import e_kdy_pro.sample.serviceImpl.MemberVO;

@Controller
public class MemberController {
	
	//회원가입 페이지로 이동 메소드
	@RequestMapping(value="/join.do")
	public String join() throws SQLException {
		
		System.out.println("회원가입이동");
		
		return "join";
		
	}
	
	
	//회원가입 처리 메소드	
	@RequestMapping(value="/joinOk.do")
	public String joinOk(MemberVO member, DAOJDBC daojdbc) throws SQLException, NoSuchAlgorithmException {
		
		System.out.println("회원가입가능");
		System.out.println(member.getTel());
		SHA256 instance = SHA256.getInstance();
		String password = instance.encrypt(member.getPassword());
		
		System.out.println("싱글톤 처리한 비밀번호 "+password);
		
		member.setPassword(password);
		
		int result = daojdbc.insertMember(member);
		
		if(result>0) {
		
			System.out.println("회원가입완료");
		
		}else {
			
			System.out.println("중복된 아이디이거나 어떤 이유로 회원가입 실패");
			
		}
		
		return "login";
		
	}
}
