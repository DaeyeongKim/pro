package e_kdy_pro.sample.web;

import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.NotFoundException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import e_kdy_pro.sample.security.SHA256;
import e_kdy_pro.sample.serviceImpl.BoardVO;
import e_kdy_pro.sample.serviceImpl.DAOJDBC;
import e_kdy_pro.sample.vo.BkieReservePlace;

@Controller
public class HomeController {
	
	private HttpSession session; //세션
	
	//홈 화면으로 이동 메소드
	@RequestMapping("/home.do")
	public String home(DAOJDBC daojdbc, Model model ) throws SQLException {
		
		int startNum = 1;
		int lastNum = 10;
	
		int count = daojdbc.selectBoardCount();
		System.out.println(count);
		int result = divisionCount(count);
		System.out.println(result);
		model.addAttribute("boardList",daojdbc.selectListBoard(startNum, lastNum));
		model.addAttribute("count",result);
		
		
		return "home";
	
	}
	
	//게시물 읽는 메소드
	@RequestMapping(value="/read.do") 
	public String read(int num, Model model, DAOJDBC daojdbc, HttpServletRequest request) throws SQLException {
		
		model.addAttribute("board",daojdbc.selectBoard(num));
		
		int checkNum = num;
		String nam = "checkNum";
		String stringValue = String.valueOf(checkNum);
		session = request.getSession();
		if(session.getAttribute(stringValue)==null) {//조회수 올라갈때
			System.out.println("조회수확인");
		session.setAttribute(stringValue, checkNum); // 로그인 되있을때 한번씩만 조회수 올리기위해 세션에 게시글 번호 등록
			
			daojdbc.changeHits(num);
			
		}
		
		return "read";
		
	}
	
	//로그인 페이지 이동 메소드
	@RequestMapping(value="/login.do")
	public String login() throws SQLException {
		
		return "login";
		
	}
	
	//로그인 메소드
	@RequestMapping(value="/loginCheck.do",method = RequestMethod.POST)
	public String loginCheck(String id, String password, HttpServletRequest request, DAOJDBC daojdbc) throws SQLException, NoSuchAlgorithmException {
		
		SHA256 instance = SHA256.getInstance();
		String SHApassword = instance.encrypt(password);//해쉬코드화
		String result = daojdbc.selectIDandPass(id, SHApassword);
		
		if(result!=null) {//로그인 가능
		
			session = request.getSession(); //세션가져오기
			session.setAttribute("userId", id); //세션 등록 (아이디)
			return "forward:home.do";
			
		}else {
		
			return "login";
			
		}
		
		
	}
	
	//로그아웃 메소드
	@RequestMapping(value="/logout.do") 
	public String logout(HttpServletRequest request) throws SQLException { 
		session = request.getSession(false);
		if(session!=null) {
			
			session.invalidate();
		
		}
		return "forward:home.do";
		
	}
	
	
	//카운트 계산 메소드
	public int divisionCount(int count) {
		
		int result = count / 10 + (count % 10 > 0 ? 1 : 0);
		
		return result;
		
	}
	
	//글쓰기로 이동 메소드
	@RequestMapping(value="/write.do") 
	public String write() throws SQLException { 
		
		
		return "write";
		
	}

	//글쓰기 등록 메소드
	@RequestMapping(value="/writeOk.do") 	
	public String writeOk(BoardVO board,DAOJDBC daojdbc) throws SQLException { 
		
		System.out.println("insert확인"+board.getContent()+" "+board.getTheme());
		
		BoardVO insertWrite = board;
		
		insertWrite.setId((String)session.getAttribute("userId"));
		daojdbc.insertBoard(insertWrite);
	
		return "forward:home.do";
		
	}
	
	//게시글 삭제 메소드 
	@RequestMapping(value="/delete.do") 
	public void delete(BoardVO board,DAOJDBC daojdbc) {
		
		daojdbc.deleteBoard(board.getNum());
		
	}
	
	
	@RequestMapping(value="/rent.do")
	public String lent(Model model, DAOJDBC daojdbc) throws SQLException {
		
		model.addAttribute("rentList",daojdbc.selectRent());
		
		return "rent";
		
	}
	
	
	
	@RequestMapping(value="/search.do",method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity searchRent(@RequestBody BkieReservePlace testRent ,DAOJDBC daojdbc, Model model) throws SQLException {
		
		ResponseEntity result = null;
		
		try {
			
		    List<BkieReservePlace> list = daojdbc.selectSearchRent(testRent.getReservePlaceName());
		    result = ResponseEntity.ok().body(list);

		} catch (Exception e) {
			
		    result = ResponseEntity
		            .status(HttpStatus.INTERNAL_SERVER_ERROR)
		            .body(e.getMessage());
		}
		
		return result; 
		
	}
}
